import { ChatUnreadProvider } from "./contexts/ChatUnReadContext";
import AppRoutes from "./routes";
import { ToastProvider } from "./components/Toast";
import ChatUnreadInitializer from"./features/chat/UnreadConversation/ChatUnReadInitializer";
import ChatUnreadSocketBridge from "./features/chat/UnreadConversation/ChatUnreadSocketBrige";

export default function App() {
  return (
    <ToastProvider>
      <ChatUnreadProvider>
        {/* Luôn luôn mount, bất kể đang đứng ở route nào */}
        <ChatUnreadInitializer />
        <ChatUnreadSocketBridge />

        <AppRoutes />
      </ChatUnreadProvider>
    </ToastProvider>
  );
}
