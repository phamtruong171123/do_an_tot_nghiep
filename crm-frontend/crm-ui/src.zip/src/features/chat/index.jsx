import React from "react";
import ChatLayout from "./ChatLayout";

import ThreadList from "./ThreadList";
import ChatHeader from "./ChatHeader";
import MessageList from "./MessageList";
import Composer from "./Composer";
import EmptyState from "./EmptyState";
import { me, threadsMock, msgsMock } from "./mocks";

export default function Chat() {
  const [activeThreadId, setActiveThreadId] = React.useState(threadsMock[0]?.id || null);
  const activeThread = threadsMock.find(t => t.id === activeThreadId) || null;
  const messages = activeThread ? msgsMock.filter(m => m.threadId === activeThread.id) : [];

  return (
    <ChatLayout
      sidebar={
        <>
          <ThreadList items={threadsMock} activeId={activeThreadId || undefined} onSelect={(id) => setActiveThreadId(id)} />
        </>
      }
      content={
        activeThread ? (
          <>
            <ChatHeader thread={activeThread} />
            <MessageList items={messages} meId={me.id} />
            <Composer onSend={(txt) => console.log("SEND:", txt)} />
          </>
        ) : (
          <EmptyState title="Select a conversation" subtitle="Choose a chat to start messaging" />
        )
      }
    />
  );
}
