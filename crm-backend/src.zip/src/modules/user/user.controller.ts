import { Request, Response } from "express";
import { prisma } from "../../prisma";
import bcrypt from "bcryptjs";
import type { Prisma, User, UserRole, UserStatus } from "@prisma/client";

// ====== Helpers ======
function parseIntOr(val: any, def: number) {
  const n = Number(val);
  return Number.isFinite(n) && n > 0 ? n : def;
}

export async function me(req: Request, res: Response) {
  const userId = Number(req.user!.id); // convert string to number
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return res.status(404).json({ message: "Not found" });
  res.json({
    id: user.id,
    username: user.username,
    fullName: user.fullName,
    email: user.email,
    role: user.role,
    status: user.status,
  });
}

// GET /api/users?q=&role=&status=&sort=createdAt:desc
export async function listUsers(req: Request, res: Response) {
  const q = (req.query.q as string | undefined)?.trim();
  const role = (req.query.role as UserRole | undefined) || undefined;
  const status = (req.query.status as UserStatus | undefined) || undefined;

  // sort
  let sortField = "createdAt" as keyof User;
  let sortDir: Prisma.SortOrder = "desc";
  if (typeof req.query.sort === "string") {
    const [f, d] = req.query.sort.split(":");
    if (["id", "username", "email", "createdAt", "updatedAt"].includes(f)) sortField = f as any;
    if (["asc", "desc"].includes((d || "").toLowerCase()))
      sortDir = d.toLowerCase() as Prisma.SortOrder;
  }

  const where: Prisma.UserWhereInput = {
    AND: [
      role ? { role } : {},
      status ? { status } : {},
      q
        ? {
            OR: [{ username: { contains: q } }, { email: { contains: q } }],
          }
        : {},
    ],
  };

  // Ngưỡng coi là "online" nếu lastOnlineAt còn mới (2 phút)
  const ONLINE_WINDOW_MS = 2 * 60 * 1000;

  const [total, items] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { [sortField]: sortDir },
      select: {
        id: true,
        username: true,
        email: true,
        fullName: true,
        role: true,
        status: true,
        agentProfile: {
          select: {
            online: true,
            userLoad: true,
            lastOnlineAt: true,
          },
        },
      },
    }),
  ]);

  const now = Date.now();
  res.json({
    items: items.map((u) => {
      const ap = u.agentProfile;
      // Tính online an toàn: cờ online + lastOnlineAt còn trong cửa sổ (nếu có)
      const derivedOnline =
        !!ap?.online && (!ap?.lastOnlineAt || now - ap.lastOnlineAt.getTime() <= ONLINE_WINDOW_MS);

      return {
        id: u.id,
        username: u.username,
        email: u.email,
        role: u.role,
        status: u.status,
        fullName: u.fullName,
        agentProfile: {
          online: derivedOnline,
          lastOnlineAt: ap?.lastOnlineAt || null,
          userLoad: ap?.userLoad ?? 0,
        },
      };
    }),
    total,
  });
}

export async function getUser(req: Request, res: Response) {
  const id = Number(req.params.id); //  ép number
  const u = await prisma.user.findUnique({ where: { id } });
  if (!u) return res.status(404).json({ message: "Not found" });
  res.json({
    id: u.id,
    username: u.username,
    fullName: u.fullName,
    email: u.email,
    role: u.role,
    status: u.status,
  });
}

export async function createUser(req: Request, res: Response) {
  try {
    const {
      username,
      email,
      password,
      role = "AGENT",
      status = "ACTIVE",
      fullName,
    } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ message: "username & password required" });
    }

    // unique checks
    const exists = await prisma.user.findFirst({
      where: { OR: [{ username }, ...(email ? [{ email }] : [])] },
      select: { id: true },
    });
    if (exists) return res.status(409).json({ message: "username/email already exists" });

    const hash = await bcrypt.hash(password, 10);

    const created = await prisma.user.create({
      data: {
        username,
        email: email ?? null,
        passwordHash: hash,
        role: role as any,
        fullName: fullName as any,
        status: status as any,
        agentProfile: {
          create: {
            online: true,
            userLoad: 0,
            lastOnlineAt: new Date(),
          },
        },
      },
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        status: true,
        agentProfile: { select: { online: true, lastOnlineAt: true } },
      },
    });

    return res.status(201).json(created);
  } catch (e: any) {
    return res.status(500).json({ message: e?.message || "Create user failed" });
  }
}

export async function updateUser(req: Request, res: Response) {
  const id = Number(req.params.id); //  ép number
  const { role, status, password, username, email, fullName } = req.body as Partial<{
    role: UserRole;
    status: UserStatus;
    password: string;
    username: string;
    email: string | null;
    fullName: string;
  }>;

  // unique check nếu đổi username/email
  if (username || typeof email !== "undefined") {
    const conflict = await prisma.user.findFirst({
      where: {
        id: { not: id }, //  id là number
        OR: [
          ...(username ? [{ username }] : []),
          ...(typeof email !== "undefined" ? [{ email: email ?? null }] : []),
        ],
      },
      select: { id: true },
    });
    if (conflict) return res.status(409).json({ message: "username/email already exists" });
  }

  const data: Prisma.UserUpdateInput = {};
  if (role) data.role = role;
  if (status) data.status = status;
  if (username) (data as any).username = username;
  if (typeof email !== "undefined") (data as any).email = email ?? null;
  if (password) (data as any).passwordHash = await bcrypt.hash(password, 10);
  if (fullName) (data as any).fullName = fullName;

  const updated = await prisma.user.update({ where: { id }, data });
  res.json({
    id: updated.id,
    username: updated.username,
    email: updated.email,
    role: updated.role,
    status: updated.status,
  });
}

export async function deleteUser(req: Request, res: Response) {
  const id = Number(req.params.id); //  ép number
  await prisma.user.delete({ where: { id } });
  res.status(204).end();
}

// ====== Self-service ======
export async function updateMe(req: Request, res: Response) {
  const id = Number(req.user!.id); // number
  const { username, email } = req.body as { username?: string; email?: string | null };

  if (!username && typeof email === "undefined") {
    return res.status(400).json({ message: "nothing to update" });
  }

  const conflict = await prisma.user.findFirst({
    where: {
      id: { not: id },
      OR: [
        ...(username ? [{ username }] : []),
        ...(typeof email !== "undefined" ? [{ email: email ?? null }] : []),
      ],
    },
    select: { id: true },
  });
  if (conflict) return res.status(409).json({ message: "username/email already exists" });

  const updated = await prisma.user.update({
    where: { id },
    data: {
      ...(username ? { username } : {}),
      ...(typeof email !== "undefined" ? { email: email ?? null } : {}),
    },
  });

  res.json({
    id: updated.id,
    username: updated.username,
    email: updated.email,
    fullName: updated.fullName,
    role: updated.role,
    status: updated.status,
  });
}

export async function changePassword(req: Request, res: Response) {
  const id = Number(req.user!.id); // number
  const { currentPassword, newPassword } = req.body as {
    currentPassword?: string;
    newPassword?: string;
  };
  if (!currentPassword || !newPassword)
    return res.status(400).json({ message: "currentPassword & newPassword required" });

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return res.status(404).json({ message: "Not found" });

  const ok = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!ok) return res.status(400).json({ message: "Current password incorrect" });

  const hash = await bcrypt.hash(newPassword, 10);
  await prisma.user.update({ where: { id }, data: { passwordHash: hash } });
  res.json({ ok: true });
}

// ====== Admin: set status ======
export async function setUserStatus(req: Request, res: Response) {
  const id = Number(req.params.id); //  ép number
  const { status } = req.body as { status?: UserStatus };
  if (!status) return res.status(400).json({ message: "status required" });

  const updated = await prisma.user.update({ where: { id }, data: { status } });
  res.json({ id: updated.id, status: updated.status });
}
